﻿TODO:
- To create an Application program, use Project > Add Application Program
- To create Hardware and Product data, use Project > Add Hardware
- To create the Catalog structure, use Project > Add Catalog
- To check the created data, use Build > Check
- To produce a product database for distribution (knxprod, vd*), use Build > Build Solution
